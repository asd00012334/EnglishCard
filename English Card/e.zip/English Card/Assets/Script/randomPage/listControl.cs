﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using UnityEngine.UI;
//using UnityEngine.UI;

public class listControl : MonoBehaviour {
    public List<strPair> lst = new List<strPair>();
    public List<string> lines = new List<string>();
    // Use this for nitialization
    public Button randBtn;
    void Start () {
        //loadFile("./save.cmos");
        randBtn.onClick.AddListener(loadFile);
        //enterButton.onClick.AddListener(enterButtonOnclick);
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public class strPair
    {
        public string eng;
        public string chi;
        strPair(string english,string chinese)
        {
            eng = english;
            chi = chinese;
        }
    }
    public void loadFile()
    {
        StreamReader sr = null;
        try
        {
            sr = new StreamReader("./save.cmos");

        }catch(Exception e)
        {
            Debug.Log("can't find file to read");
            return;
        }

        string line;
        int num = 0;
        while( (line=sr.ReadLine()) !=null)
        {
            num++;
            lines.Add(line);
        }

        sr.Close();
        sr.Dispose();

        /*for(int i=0;i<num;i++)
        {
            Debug.Log(lst[i]);
        }*/
        Debug.Log(lst[0]);
    }
}
