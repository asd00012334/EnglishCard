﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.IO;

public class InOut : MonoBehaviour {
    public InputField engIn;
    public InputField manIn;
    public Button enterButton;
    // Use this for initialization
    void Start () {
       // enterButton = GetComponent<Button>();
       // engIn = GetComponent<InputField>();
        //manIn = GetComponent<InputField>();
        enterButton.onClick.AddListener(enterButtonOnclick);
        
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    void enterButtonOnclick()
    {
        StreamWriter saveFile = File.AppendText("./save.cmos");
       // saveFile.WriteLine("YAYAYAYAYAYAYA");
        Debug.Log(engIn.text);
        saveFile.Write(engIn.text + " " + manIn.text);
        saveFile.Close();
    }
}
